exports.handler = (event, context, callback) => {
	console.log('--- event');
	console.log(event);

	if (event.action != null && event.action == 'warmup') {
		console.log('--- warmup event');
		callback(null, "ok");
		return;
	}

	callback(null, "ok");
}
